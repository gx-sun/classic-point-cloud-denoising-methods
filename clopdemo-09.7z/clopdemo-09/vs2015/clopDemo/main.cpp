//=============================================================================
// CLOP Source
//-----------------------------------------------------------------------------
// Reference Implementation for
// Preiner et al., Continuous Projection for Fast L1 Reconstruction, In 
// Proceedings of ACM SIGGRAPH 2014
// www.cg.tuwien.ac.at/research/publications/2014/preiner2014clop
//-----------------------------------------------------------------------------
// (c) Reinhold Preiner, Vienna University of Technology, 2014
// All rights reserved. This code is licensed under the New BSD License:
// http://opensource.org/licenses/BSD-3-Clause
// Contact: rp@cg.tuwien.ac.at
//=============================================================================


#define _SILENCE_STDEXT_HASH_DEPRECATION_WARNINGS
#include "mixture.hpp"
#include "clop.hpp"
#include <vector>
#include <fstream>
#include <iostream>
#include <string>
#include <iostream> //for cout
#include <io.h>     //for _finddata_t�� _findnext
#include "plyio.hpp"

using namespace cp;

#include <iostream>
using namespace std;

#include "nanooff.hpp"

vector<string> getFilesList(string dir)
{
	vector<string> allPath;
	// ��Ŀ¼�������"\\*.*"���е�һ������
	string dir2 = dir + "\\*.*";

	intptr_t handle;
	_finddata_t findData;

	handle = _findfirst(dir2.c_str(), &findData);
	if (handle == -1) {// ����Ƿ�ɹ�
		cout << "can not found the file ... " << endl;
		return allPath;
	}
	do
	{
		if (findData.attrib & _A_SUBDIR) //�Ƿ�����Ŀ¼
		{
			//������Ŀ¼Ϊ"."��".."���������һ��ѭ�������������Ŀ¼������������һ������
			if (strcmp(findData.name, ".") == 0 || strcmp(findData.name, "..") == 0)
				continue;

			// ��Ŀ¼�������"\\"����������Ŀ¼��������һ������
			string dirNew = dir + "\\" + findData.name;
			vector<string> tempPath = getFilesList(dirNew);
			allPath.insert(allPath.end(), tempPath.begin(), tempPath.end());
		}
		else //������Ŀ¼�������ļ���������ļ������ļ��Ĵ�С
		{
			string filePath = dir + "\\" + findData.name;
			allPath.push_back(filePath);
			//cout << filePath << "\t" << findData.size << " bytes.\n";
		}
	} while (_findnext(handle, &findData) == 0);
	_findclose(handle);    // �ر��������
	return allPath;
}


void main()
{
	string dir = "data/noise/";
	vector<string>allPath = getFilesList(dir);
	
	for (auto i = 0; i < allPath.size(); i++)
	{
		string filenameIn = allPath.at(i);//"pointcloud.off";
		string filenameOut = "data/result_pulse_20/"+ allPath.at(i).substr(11, allPath.at(i).size() - 4 - 11) + "_CLOP.off";


		cout << "CLOP Demo" << endl;


		// 1. Initialize Point Set

		nanooff::Info offInfo(filenameIn);
		if (!offInfo.getSignatureOK())
		{
			cerr << "Can't load input point cloud '" << filenameIn << "'" << endl;
			return;
		}
		PointSet* points = new PointSet(offInfo.getVertexCount());
		nanooff::loadPointCloud(filenameIn, (float*)points->data());


		// 2. Compute mixture using HEM

		// set mixture parameters
		Mixture::Params mParams;
		mParams.globalInitRadius = 0.01f;		// 0.9 (0.05)global initialization kernel radius (applies only if useGlobalInitRadius == true)
		mParams.useGlobalInitRadius = true;		// use global initialization radius instead of NNDist sampling (more stable for non-uniform point sampling)
		mParams.useWeightedPotentials = true;	// if true, performs WLOP-like balancing of the initial Gaussian potentials
		mParams.alpha = 2.3f;					// multiple of cluster maximum std deviation to use for query radius (<= 2.5f recommended)
		mParams.nLevels = 4;					// number of levels to use for hierarchical clustering

		Mixture* M = new Mixture(points, mParams);


		// 3. Perform CLOP on M
		cout << endl;

		// set CLOP parameters

		clop::Params clopParams;
		clopParams.nIterations = 6;			// number of CLOP iterations
		clopParams.kernelRadius = 0.3f;			//4(0.4) basic kernel radius
		clopParams.doubleInitRadius = true;		// doubles the kernel radius for the initial iteration (recommended for more stable initialization in the presence of stronger outliers)
		clopParams.interleaveRepulsion = true;	// use interleaved repulsion from the CLOP paper (recommended)
		clopParams.repulsionRadiusFac = 0.5f;	//0.5 repulsion kernel radius factor for kernel cutoff (1 - full repulsion, 0 - no repulsion). recommended value is ~ 0.5
		clopParams.useSoftEta = true;			// uses the more gently decreasing eta = -r from Huang et al. instead of the original eta = 1/(3r? from Lipman et al. (recommended)
		clopParams.mu = 0.4f;					// 0.4balancing factor between attraction and repulsion forces; E = attracion + ?* repulsion, ?\in [0, 0.5]
		clopParams.useDiscreteLOP = false;		// ignores Gaussian covariances for comparison purposes. applies original WLOP using the Gaussian centers for singular attraction only.


		// optional: take subset of input points for projection
		PointSet* particles = new PointSet();
		for (uint i = 0; i < points->size(); i += 1)//origin 2
			particles->push_back(points->at(i));


		PointSet* projectedPoints = clop::project(particles, M, clopParams);


		// 4. write projected points
		nanooff::savePointCloud(filenameOut, (float*)projectedPoints->data(), projectedPoints->size());
	}
}

